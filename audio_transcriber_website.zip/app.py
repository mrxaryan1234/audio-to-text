import os
from flask import Flask, request, render_template, redirect, flash
import openai

app = Flask(__name__)
app.secret_key = "secret"

# 👇 OpenAI Whisper API Key यहाँ लगा दी गई है (डेमो के लिए)
openai.api_key = "sk-1234567890ABCDEFGHIJKLMNOPQ"  # ← यहाँ अपनी असली API Key लगाएं

@app.route("/", methods=["GET", "POST"])
def index():
    transcript = None

    if request.method == "POST":
        file = request.files.get("audio_file")
        if not file or file.filename == "":
            flash("कृपया एक ऑडियो फाइल चुनें")
            return redirect("/")

        try:
            response = openai.Audio.transcribe(
                model="whisper-1",
                file=file,
                response_format="text"
            )
            transcript = response
        except Exception as e:
            flash("Error: " + str(e))

    return render_template("index.html", transcript=transcript)

if __name__ == "__main__":
    app.run(debug=True)
